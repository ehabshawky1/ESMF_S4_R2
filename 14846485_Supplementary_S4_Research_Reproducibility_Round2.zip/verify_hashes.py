from pathlib import Path
import hashlib,csv
r=Path(__file__).resolve().parent
rows=list(csv.DictReader((r/'SHA256_MANIFEST.csv').open(encoding='utf-8-sig')))
for row in rows:
 p=r/row['path'];assert p.is_file(),row['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],row['path']
print('SHA256_SOURCE_PASS',len(rows))
