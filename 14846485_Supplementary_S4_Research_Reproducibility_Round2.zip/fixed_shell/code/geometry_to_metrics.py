#!/usr/bin/env python3
"""Produce reproducible SVG and area metrics from the declared JSON rectangles.
Axis-aligned exact edge-cell partition, no raster. Independently cross-check via
Shapely on request (Shapely is not needed for the primary algorithm).
Denominator: area of unique pressure, NOT net floor area.
"""
from pathlib import Path
from collections import defaultdict
import argparse,csv,json,hashlib,xml.etree.ElementTree as ET
import numpy as np
BASE=Path(__file__).resolve().parent.parent
NS='http://www.w3.org/2000/svg'
def area_mask(bounds):
 return (bounds[2]-bounds[0])*(bounds[3]-bounds[1])/10000
def reconstructed_pressure(scene):
 hard={h['id']:h for h in scene['technology_hard_footprints']}
 from collections import Counter
 mn=Counter();sf=Counter();hc=Counter(h['source_group'] for h in scene['technology_hard_footprints'])
 output=[]
 for o in scene['pressure_fields']:
  method=o.get('construction',{}).get('method')
  if o['category'] in ('t_min','t_soft'):
   assert method=='hard_rect_plus_declared_edge_offsets',o['id']
   h=hard[o['construction']['anchor_id']]
   assert h['source_group']==o['source_group'],o['id']
   rect=[round(h['rect_svg_units'][i]+o['construction']['offsets_svg_units'][i],7) for i in range(4)]
   assert max(abs(rect[i]-o['rect_svg_units'][i]) for i in range(4)) <1e-6,('DECLARED_T_GEOMETRY_MISMATCH',o['id'])
   (mn if o['category']=='t_min' else sf)[o['source_group']]+=1
  else:
   assert method=='explicit_archived_rectangle_no_parent_id',o['id']
   rect=o['rect_svg_units']
  assert rect[2]>rect[0] and rect[3]>rect[1]
  output.append((o,rect))
 assert mn==sf==hc,('DEVICE_PAIRING_INCOMPLETE',mn,sf,hc)
 return output

def clipped(r,net):
 a,b,c,d=max(r[0],net[0]),max(r[1],net[1]),min(r[2],net[2]),min(r[3],net[3]);return [a,b,c,d] if a<c and b<d else None
def render(scene,svg_path):
 # White-background audit SVG GENERATED FROM JSON, not historical Figure 6
 root=ET.Element('svg',{'xmlns':NS,'viewBox':'0 0 1000 1600','width':'500','height':'800'})
 ET.SubElement(root,'rect',{'x':'0','y':'0','width':'1000','height':'1600','fill':'white'})
 net=scene['net_shell_svg_units'];ET.SubElement(root,'rect',{'x':str(net[0]),'y':str(-net[3]),'width':str(net[2]-net[0]),'height':str(net[3]-net[1]),'fill':'none','stroke':'black','stroke-width':'6'})
 for o,raw in reconstructed_pressure(scene):
  b=clipped(raw,net)
  if b is None: continue
  colors={'t_min':'#4f7dbf','t_soft':'#88b9d6','f_buffer':'#d0b35d','service':'#c58fae'}
  ET.SubElement(root,'rect',{'x':str(b[0]),'y':str(-b[3]),'width':str(b[2]-b[0]),'height':str(b[3]-b[1]),'fill':colors[o['category']],'fill-opacity':'.13','stroke':colors[o['category']],'stroke-width':'.9','data-id':o['id'],'data-category':o['category'],'data-source':o['source_group']})
 for o in scene['technology_hard_footprints']:
  b=clipped(o['rect_svg_units'],net)
  if b is None:continue
  ET.SubElement(root,'rect',{'x':str(b[0]),'y':str(-b[3]),'width':str(b[2]-b[0]),'height':str(b[3]-b[1]),'fill':'#a02929','fill-opacity':'.6','data-id':o['id'],'data-source':o['source_group']})
 ET.ElementTree(root).write(svg_path,encoding='utf-8',xml_declaration=True)
def calc(scene,independent=True):
 net=scene['net_shell_svg_units'];expected_area=area_mask(net)
 assert abs(expected_area-scene['net_shell_m2'])<1e-9
 obs=[];partially_outside=[]
 for o,raw in reconstructed_pressure(scene):
  b=clipped(raw,net)
  if b is None:continue
  if raw!=b:partially_outside.append(o['id'])
  obs.append((o,b))
 x=np.array(sorted(set([net[0],net[2]]+[p for o,b in obs for p in (b[0],b[2])])),float)
 y=np.array(sorted(set([net[1],net[3]]+[p for o,b in obs for p in (b[1],b[3])])),float)
 cx=(x[1:]+x[:-1])/2;cy=(y[1:]+y[:-1])/2
 cells=np.outer(np.diff(y),np.diff(x))/10000
 shape=cells.shape
 counts=np.zeros(shape,dtype=np.uint16)
 groups=defaultdict(lambda:np.zeros(shape,dtype=np.uint16))
 categories=defaultdict(lambda:np.zeros(shape,dtype=np.uint16))
 t_min=defaultdict(lambda:np.zeros(shape,dtype=bool));t_soft=defaultdict(lambda:np.zeros(shape,dtype=bool))
 for o,b in obs:
  m=(cy[:,None]>=b[1])&(cy[:,None]<b[3])&(cx[None,:]>=b[0])&(cx[None,:]<b[2])
  counts+=m;groups[o['source_group']]+=m;categories[o['category']]+=m
  if o['category']=='t_min':t_min[o['source_group']]|=m
  if o['category']=='t_soft':t_soft[o['source_group']]|=m
 source_count=np.zeros(shape,dtype=np.uint16)
 for m in groups.values():source_count+=(m>0)
 raw=(counts>=2);cross=(source_count>=2)
 nested=np.zeros(shape,dtype=bool)
 for k in t_min:nested|=(t_min[k]&t_soft[k])
 fixture_only=np.zeros(shape,dtype=bool)
 for k,c in groups.items():
  if k.startswith('FAMILY::'):fixture_only|=(c>=2)
 pure_t=raw&(source_count==1)&nested
 pure_f=raw&(source_count==1)&fixture_only
 residual=raw&(source_count==1)&~(nested|fixture_only)
 mixed=raw&cross&nested
 def A(m):return float(cells[m].sum())
 # Exclusivity means 4 pieces exactly partition raw overlap
 assert abs(A(pure_t)+A(pure_f)+A(residual)+A(cross)-A(raw))<1e-7
 unique=A(counts>=1);raw_area=A(raw);cross_area=A(cross)
 metrics={
  'scenario':scene['scenario'],'source_kind':scene['source_kind'],
  'scene_sha256':hashlib.sha256(json.dumps(scene,sort_keys=True).encode()).hexdigest(),
  'original_source_sha256':scene['source_sha256'],'net_shell_m2':expected_area,
  'pressure_field_count':len(obs),'device_count':len(scene['technology_hard_footprints']),
  'unique_m2':unique,'raw_overlap_m2':raw_area,'raw_ratio_pct':100*raw_area/unique,
  'cross_source_m2':cross_area,'cross_source_ratio_pct':100*cross_area/unique,
  'pure_same_device_nesting_m2':A(pure_t),'pure_fixture_family_nesting_m2':A(pure_f),
  'pure_other_within_group_m2':A(residual),'cross_source_with_device_nesting_m2':A(mixed),
  'partially_outside_pressure_field_count':len(partially_outside)}
 if independent:
  from shapely.geometry import box
  from shapely.ops import unary_union
  geoms=[box(*b) for o,b in obs]
  sh_u=unary_union(geoms).area/10000
  unique_g={k:unary_union([box(*b) for o,b in obs if o['source_group']==k]) for k in groups}
  q=list(unique_g.values())
  intersections=[q[i].intersection(q[j]) for i in range(len(q)) for j in range(i+1,len(q)) if q[i].intersects(q[j])]
  sh_cross=unary_union(intersections).area/10000 if intersections else 0.0
  assert abs(sh_u-unique)<1e-7,(scene['scenario'],'unique',sh_u,unique)
  assert abs(sh_cross-cross_area)<1e-7,(scene['scenario'],'cross',sh_cross,cross_area)
  metrics['independent_shapely_verified']='YES'
 return metrics

def main():
 p=argparse.ArgumentParser();p.add_argument('--skip-independent',action='store_true');args=p.parse_args()
 (BASE/'reconstructed_svgs').mkdir(parents=True,exist_ok=True)
 results=[]
 for tag in ('L1','L2','L3','L4'):
  scene=json.loads((BASE/'generated_scenes'/f'{tag}.json').read_text())
  render(scene,BASE/'reconstructed_svgs'/f'{tag}_SCENE_RECONSTRUCTED_NOT_PUBLISHED.svg')
  results.append(calc(scene,not args.skip_independent))
 out=BASE/'results';out.mkdir(exist_ok=True)
 with (out/'geometry_metrics.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(results[0]));w.writeheader();w.writerows(results)
 (out/'geometry_metrics.json').write_text(json.dumps(results,indent=2)+'\n')
 for r in results: print(r['scenario'],f"unique={r['unique_m2']:.6f}",f"raw={r['raw_overlap_m2']:.6f}",f"cross={r['cross_source_m2']:.6f}",r.get('independent_shapely_verified','SINGLE_METHOD'))
 print('DERIVED_GEOMETRY_VERIFICATION_PASS= True')
if __name__=='__main__':main()
