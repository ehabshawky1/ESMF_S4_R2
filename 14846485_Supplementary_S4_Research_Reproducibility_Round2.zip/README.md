# Supplementary Material S4 — Revised research geometry and sensitivity reproducibility

**Manuscript 14846485, Round 2 research-only supplement.** The package is not the full ESMF Streamlit application source and it does not reproduce the historical (unavailable) calculation behind the originally submitted Table 10. It reproduces a declared reanalysis of original **archived derived** fixed-shell drawings and preserves the earlier generated-minimum hard-geometry benchmarks as a separate track.

## Scope, sources and limitations
- `fixed_shell/declared_geometry_recipes/L1–L4.json`: archived placement centres, hard-device sizes, minimum/soft field offsets, and fixture/service field extents, with source SVG SHA-256 values. `code/construct_declared_geometry.py` reconstructs all the research rectangles from these declared numerical inputs before area calculations; the original direct-rectangle scenes under `fixed_shell/scenes/` are frozen cross-checks.
- `fixed_shell/archived_derived_pressure_svg/`: recovered May 2026 pressure drawings (derived visual sources, NOT original historical Table 10 run).
- `fixed_shell/code/geometry_to_metrics.py`: regenerates device minimum/soft polygons from hard footprints and recorded edge offsets, computes exact edge-partition union and nested/cross-source pressure, and independently checks with Shapely.
- **Explicit reconstruction boundary:** T-device minimum/soft fields are generated from footprint centres, sizes and offsets. Fixture and service pressure rectangles are reconstructed from archival field centres and extents, **not** from recovered automatic fixture or queue-placement rules. Their centres/sizes are retrospective transformations of surviving derived geometry, not independently observed placements. Therefore this is **geometry-to-metrics reproducibility for the declared archive**, not full generative-model reproducibility.
- `sensitivity/`: 80 controlled archived-geometry case calculations at fixed device counts and placement centres. Its script imports the single research geometry routine in `fixed_shell/code/` and reads the same `fixed_shell/scenes/` inputs. No duplicate copies of code/scenes or ESMF application modules are distributed. Geometry expansion beyond the shell is flagged, not asserted feasible.
- `benchmarks_generated_minimum/`: L2-Min–L4-Min historical generated-minimum hard-obstacle SVG benchmark. These share technology counts but *not necessarily pressure-field generation settings* with fixed-shell source drawings.
- `reference_original_snapshot/`: the earlier submitted scenario input and parameter JSON. The independent generated-minimum hard-geometry checker is retained once under `code/minimum_hard_geometry_audit.py`. The old expected-output pressure table and arithmetic-only pressure reproduction script are **intentionally superseded** because their fixed-shell values are not reproducible from the recovered source geometry.
- `data/`: parameter-by-parameter provenance, sensitivity factor ranges, survey *aggregate only*, and clearly marked researcher-summary expert matrix. No identifiable raw interviews or shopper-level responses are released.

**Conceptual boundary:** all-condition layering counts separate minimum/soft fields even within one device; conservative distinct-source overlap groups them by demand source and aggregates fixture fields by family if original individual fixture IDs are not preserved. Union/overlap measurements do not prove layout accessibility or actual crowding. An exploratory 50% reference is not an operational limit. Clipping pressure polygons does not certify protected clearance.

## Reproduce (Python 3.11+)
1. `python -m pip install -r requirements.txt`
2. `python run_all.py` (first constructs all fixed-shell geometry from the declared placement/dimension recipes, checks it against archived rectangles, then computes fixed-shell metrics, 80 sensitivity cases, and generated-minimum hard geometry).
3. See `results/fixed_shell_metrics.csv`, `sensitivity/results/Phase7_All_Sensitivity_Cases.csv`, and `results/run_report.json`.
4. `python verify_hashes.py` checks unmodified packaged source/records. It excludes regenerated outputs. See also `DECLARED_GEOMETRY_RECONSTRUCTION_SCOPE.md` for the boundary between archive-reconstruction and the unrecovered automatic placement process.

The fixed-shell CSV is the authoritative numerical source for *revised Table 10 and Supplementary S1.2*. Source precision is maintained internally; journal tables display rounded values. The original previous-submission fixed-shell Table 10 series is a historical record, **not an alternate validated result**. Reviewer responses should not claim the original run was recovered.

## Application intellectual property / excluded files
This supplement provides **research-specific independent verification scripts**, not the Python/Streamlit application. It intentionally excludes `app.py`, `engine.py`, zoning, circulation, technology-placement and export modules, the installation package, and the full ESMF layout-generation source tree. The explicit L1–L4 scene JSONs are scientific input records, not implementation code for generating commercial store layouts. Reproducibility here is limited to archived-derived pressure geometry and its stated measurements, not to the complete original design-generation process or historical original Table 10 run. The previous protected S4 scope remains protected, while the reviewer-requested independent research calculations are added.

The files under `data/` are aggregate/provenance artefacts only. Individual shopper responses, named interview recordings, and consent records are not distributed.


## Additional risk-closure tests
See `RISK_CLOSURE_PROTOCOL.md`. The L2-derived reusable technology templates test L3 and L4 field-rule consistency; the Table 10 ledger preserves the earlier and superseding figures, with their source limits. Both are included in `run_all.py` and can be inspected independently.
