# Declared geometry reconstruction and protected scope

The reviewer requested procedures for generating geometries and measured areas. `code/construct_declared_geometry.py` is a **research-only** geometry constructor, independent of the commercial layout planner.

1. For each documented technology device, the input specifies the archived centre and width/depth. Hard footprint rectangles are constructed from these inputs.
2. Minimum/soft rectangles are constructed from each hard footprint and its documented four edge offsets.
3. For each archived fixture-browsing and service field, the source input specifies its recorded centre and width/depth. Its rectangular geometry is constructed from those explicit placement/size inputs.
4. Every reconstructed rectangle is compared with the frozen archived scene and linked to the archived derived SVG hash; mismatches fail rather than being repaired.
5. The independent edge-cell grid and Shapely methods then calculate union, all-condition overlap and conservative cross-source overlap. The study's spatial sensitivity cases are recalculated using these constructed reference scenes.

**Critical provenance limits.** The archived fixture/service positions and extents were measured from surviving derived pressure drawings. Their original upstream placement/queue-generation rules were not retained. The recipe representation is a *retrospective, lossless reparameterisation* of surviving source geometry, not independent recovery of the original automatic planner, an additional validation sample, or the historical computation behind superseded Table 10. Do not describe it as such. Recorded fixture IDs were not recovered, so within-family aggregation is conservative. No full Streamlit application, layout-generation modules, or interview/customer raw files are released. Area calculations do not establish physical crowding or store compliance.
