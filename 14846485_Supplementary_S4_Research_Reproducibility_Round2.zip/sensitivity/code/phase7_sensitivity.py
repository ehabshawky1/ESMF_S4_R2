#!/usr/bin/env python3
"""ESMF Phase 7 exploratory spatial sensitivity for archived derived layouts ONLY.
DOES NOT reproduce original Table 10 generating run or certify compliance.
All perturbations are preregistered illustrative changes in metres, keeping source
counts and hard-device center coordinates fixed; no device is added/removed.
"""
from pathlib import Path
from collections import Counter
import copy,csv,hashlib,json,sys,math
from collections import defaultdict
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'fixed_shell'/'code'))
from geometry_to_metrics import calc,reconstructed_pressure,clipped
P=Path(__file__).resolve().parent.parent
SRC=P.parent/'fixed_shell'/'generated_scenes'; OUT=P/'results';OUT.mkdir(exist_ok=True)
METRES=100

# Parameter grid *only* EB-C modelling assumptions from Phase6 audit, not legal rules.
# 'level' low/high (at baseline 0) and quantitative perturbation in metres.
PARAMS=[
 ('minimum_front',-.2,.2,'T minimum interaction field advance, all present technologies'),
 ('soft_front',-.4,.4,'T soft field advance, non-checkout present technologies'),
 ('lateral_both',-.1,.1,'T min and soft transverse allowance changed together to preserve nesting'),
 ('checkout_soft_front',-.6,.6,'T8/T9 soft front queue/interaction allowance'),
 ('hard_size_scale',.9,1.1,'T physical footprint ±10% around fixed centre, offsets anchored to resized hard'),
 ('service_checkout_depth',-.3,.3,'Archived independent checkout-service field positive-y edge (illustrative)'),
 ('service_fitting_depth',-.3,.3,'Archived fitting service field positive-y edge (illustrative)'),
 ('fixture_browsing_scale',.9,1.1,'Archived F browsing fields scaled about centres by 10% (diagnostic)'),
]
CASE_SPECS=[('BASE','none',0.,'Reference archived derived geometry')]
for p,low,high,description in PARAMS:
 CASE_SPECS += [(p+'_LOW',p,low,description),(p+'_HIGH',p,high,description)]
CASE_SPECS += [('MULTIFIELD_LOW','combined',-1.,'min, soft, transverse, checkout, fitting and fixture lower'),('MULTIFIELD_HIGH','combined',1.,'min, soft, transverse, checkout, fitting and fixture higher')]
CASE_SPECS += [('F_SOURCE_INDIVIDUAL','fine_fixture_ids',1.,'Alternative independent identification for each fixture browsing field; not the established fixture identity')]


def lateral_and_front_indices(offset):
 """Determine the front one-sided face and lateral two-sided faces from the declared offsets.
 All supported archived device envelopes have one zero longitudinal offset and other nonzero,
 and paired lateral extents near-equal. This is geometry-derived, NOT a universal device rule.
 """
 l,b,r,t=offset
 x_one=(abs(l)<1e-8 and r>0) or (abs(r)<1e-8 and l<0)
 y_one=(abs(b)<1e-8 and t>0) or (abs(t)<1e-8 and b<0)
 if x_one and not y_one:return (2 if r else 0),(1,3)
 if y_one and not x_one:return (3 if t else 1),(0,2)
 raise ValueError('cannot classify one-sided front direction of '+str(offset))

def apply(scene,case,kind,value):
 s=copy.deepcopy(scene)
 hard={o['id']:o for o in s['technology_hard_footprints']}
 # Hard centre remains fixed (not a redesign). Spatial offset parent references are preserved.
 if kind=='hard_size_scale':
  for h in hard.values():
   a,b,c,d=h['rect_svg_units'];mx=(a+c)/2;my=(b+d)/2
   dx=(c-a)*value/2;dy=(d-b)*value/2
   h['rect_svg_units']=[mx-dx,my-dy,mx+dx,my+dy]
 for o in s['pressure_fields']:
  cat=o['category'];sg=o['source_group'];cons=o['construction']
  if cat in ('t_min','t_soft'):
   offsets=cons['offsets_svg_units']
   f,side=lateral_and_front_indices(offsets)
   tid=sg.split('_')[0]
   delta=0.0;side_change=0.0
   if kind=='minimum_front' and cat=='t_min':delta=value
   if kind=='soft_front' and cat=='t_soft' and tid not in ('T8','T9'):delta=value
   if kind=='checkout_soft_front' and cat=='t_soft' and tid in ('T8','T9'):delta=value
   if kind=='lateral_both':side_change=value
   if kind=='combined':
    delta=(.2 if cat=='t_min' else (.6 if tid in ('T8','T9') else .4))*value
    side_change=.1*value
   if delta:
    offsets[f] += (1 if offsets[f]>0 else -1)*delta*METRES
   if side_change:
    for j in side:offsets[j] += (1 if offsets[j]>0 else -1)*side_change*METRES
   assert (offsets[f] > 0 if f in (2,3) else offsets[f] < 0),('negative front extent',sg,case)
   # Detect negative side half-buffer; fail rather than quietly repair.
   for j in side:assert abs(offsets[j])>1e-6,(sg,case)
   anchor=hard[cons['anchor_id']]['rect_svg_units']
   o['rect_svg_units']=[anchor[i]+offsets[i] for i in range(4)]
  elif cat=='service' and ((kind=='service_checkout_depth' and o['layer']=='CHECKOUT_BUFFER') or (kind=='service_fitting_depth' and o['layer']=='FITTING_AREA_BUFFER') or (kind=='combined' and o['layer'] in ('CHECKOUT_BUFFER','FITTING_AREA_BUFFER'))):
   # Scenario Y convention: upper edge (higher y) points toward display/sales.
   diff= (.3*value if kind=='combined' else value)*METRES
   o['rect_svg_units'][3]+=diff
  elif cat=='f_buffer' and kind in ('fixture_browsing_scale','combined'):
   scl=value if kind=='fixture_browsing_scale' else (1+value*.1)
   a,b,c,d=o['rect_svg_units'];xm=(a+c)/2;ym=(b+d)/2
   o['rect_svg_units']=[xm-(c-a)*scl/2,ym-(d-b)*scl/2,xm+(c-a)*scl/2,ym+(d-b)*scl/2]
  if kind=='fine_fixture_ids' and cat=='f_buffer':
   # Only a hypothetical grouping bound: do not claim individual fixture identity is verified.
   o['source_group']='HYPOTHETICAL_INDEPENDENT_FIXTURE::'+o['id']
 # Validate declared offsets and parent containment (the soft field must contain the minimum).
 pa={o['source_group']:o for o in s['pressure_fields'] if o['category']=='t_min'}
 pb={o['source_group']:o for o in s['pressure_fields'] if o['category']=='t_soft'}
 assert pa.keys()==pb.keys()
 for g in pa:
  a=pa[g]['rect_svg_units'];b=pb[g]['rect_svg_units']
  if not (b[0]<=a[0]+1e-8 and b[1]<=a[1]+1e-8 and b[2]>=a[2]-1e-8 and b[3]>=a[3]-1e-8):
   raise ValueError('MIN_NOT_CONTAINED_IN_SOFT for '+case+':'+g)
 # Preserve unchanged IDs, counts, centre coordinates; only the declared sensitivity may modify shape.
 assert Counter(h['source_group'].split('_')[0] for h in hard.values())==Counter(scene['technology_device_counts']) or len(hard)==0
 return s

def hard_outside(s):
 n=s['net_shell_svg_units'];return sum(any(h['rect_svg_units'][j] < n[j]-1e-7 for j in (0,1)) or any(h['rect_svg_units'][j]>n[j]+1e-7 for j in (2,3)) for h in s['technology_hard_footprints'])

def profile(s,independent=False):
 # Phase 5 exact-grid analysis; always check internal disjoint-area assertions.
 m=calc(s,independent=independent)
 # No person-based crowding or behavioural extrapolations.
 return m

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
 rows=[];baselines={}; scenes={}
 for tag in ('L1','L2','L3','L4'):
  scenes[tag]=json.loads((SRC/f'{tag}.json').read_text())
  baselines[tag]=profile(scenes[tag],True)
 for tag,s in scenes.items():
  original_ids=[(o['id'],o['category']) for o in s['pressure_fields']]
  orig_dev=[(h['id'],h['source_group'],[(h['rect_svg_units'][i]+h['rect_svg_units'][i+2])/2 for i in (0,1)]) for h in s['technology_hard_footprints']]
  for case,kind,value,description in CASE_SPECS:
   t=apply(s,case,kind,value)
   assert [(o['id'],o['category']) for o in t['pressure_fields']]==original_ids
   assert [(h['id'],h['source_group'],[(h['rect_svg_units'][i]+h['rect_svg_units'][i+2])/2 for i in (0,1)]) for h in t['technology_hard_footprints']]==orig_dev
   m=profile(t,independent=case in ('BASE','MULTIFIELD_LOW','MULTIFIELD_HIGH','F_SOURCE_INDIVIDUAL'))
   b=baselines[tag]
   out={
    'scenario':tag,'case':case,'factor':kind,'level':value,'description':description,
    'device_count_fixed':len(t['technology_hard_footprints']),
    'field_count_fixed':len(t['pressure_fields']),
    'hard_footprints_outside_net_count':hard_outside(t),
    'pressure_fields_partial_outside_net_count':m['partially_outside_pressure_field_count'],
    'unique_m2':m['unique_m2'],
    'overlap_all_m2':m['raw_overlap_m2'],
    'overlap_ratio_pct':m['raw_ratio_pct'],
    'cross_source_m2':m['cross_source_m2'],
    'cross_source_ratio_pct':m['cross_source_ratio_pct'],
    'pure_same_device_m2':m['pure_same_device_nesting_m2'],
    'pure_fixture_group_m2':m['pure_fixture_family_nesting_m2'],
    'cross_and_same_device_m2':m['cross_source_with_device_nesting_m2'],
    'delta_unique_m2':m['unique_m2']-b['unique_m2'],
    'delta_all_overlap_m2':m['raw_overlap_m2']-b['raw_overlap_m2'],
    'delta_all_ratio_pp':m['raw_ratio_pct']-b['raw_ratio_pct'],
    'delta_cross_m2':m['cross_source_m2']-b['cross_source_m2'],
    'delta_cross_ratio_pp':m['cross_source_ratio_pct']-b['cross_source_ratio_pct'],
    'grid_and_shapely_independently_checked':m.get('independent_shapely_verified','NO'),
    'provenance':'ARCHIVED_DERIVED_SVG_ONLY_NOT_TABLE10'
   }
   rows.append(out)
 # Invariants baseline exact from prior phase within rounding.
 expected={'L1':(74.2,26.94,10.44),'L2':(74.44,46.82,18.46),'L3':(76.33,52.34,12.32),'L4':(87.66,66.87,25.67)}
 for tag in expected:
  b=baselines[tag]
  for new,reference in zip((b['unique_m2'],b['raw_overlap_m2'],b['cross_source_m2']),expected[tag]):
   assert abs(new-reference)<.02,(tag,new,reference)
 # Write full table, robust per-case aggregation, stability claims under controlled variants.
 table=OUT/'Phase7_All_Sensitivity_Cases.csv'
 with table.open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 paired=[]
 for fac,*_ in PARAMS:
  for tag in scenes:
   lo=next(r for r in rows if r['scenario']==tag and r['case']==fac+'_LOW')
   hi=next(r for r in rows if r['scenario']==tag and r['case']==fac+'_HIGH')
   paired.append({'scenario':tag,'factor':fac,
    'all_ratio_low_pct':lo['overlap_ratio_pct'],'all_ratio_high_pct':hi['overlap_ratio_pct'],
    'all_ratio_range_pp':abs(hi['overlap_ratio_pct']-lo['overlap_ratio_pct']),
    'cross_ratio_low_pct':lo['cross_source_ratio_pct'],'cross_ratio_high_pct':hi['cross_source_ratio_pct'],
    'cross_ratio_range_pp':abs(hi['cross_source_ratio_pct']-lo['cross_source_ratio_pct']),
    'all_overlap_area_range_m2':abs(hi['overlap_all_m2']-lo['overlap_all_m2']),
    'cross_overlap_area_range_m2':abs(hi['cross_source_m2']-lo['cross_source_m2']),
    'hard_outside_max':max(lo['hard_footprints_outside_net_count'],hi['hard_footprints_outside_net_count'])})
 with (OUT/'Phase7_Factor_Ranges.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(paired[0]));w.writeheader();w.writerows(paired)
 stability=[]
 for case,*_ in CASE_SPECS:
  items={x['scenario']:x for x in rows if x['case']==case}
  stability.append({'case':case,
   'L2_to_L3_all_delta_pp':items['L3']['overlap_ratio_pct']-items['L2']['overlap_ratio_pct'],
   'L2_to_L3_cross_delta_pp':items['L3']['cross_source_ratio_pct']-items['L2']['cross_source_ratio_pct'],
   'all_L2_to_L3_positive':items['L3']['overlap_ratio_pct']>items['L2']['overlap_ratio_pct'],
   'cross_L2_to_L3_positive':items['L3']['cross_source_ratio_pct']>items['L2']['cross_source_ratio_pct'],
   'any_cross_over_50':any(items[tag]['cross_source_ratio_pct']>50 for tag in scenes),
   'L2_all_over_50':items['L2']['overlap_ratio_pct']>50,'L3_all_over_50':items['L3']['overlap_ratio_pct']>50,'L4_all_over_50':items['L4']['overlap_ratio_pct']>50})
 with (OUT/'Phase7_Robustness_and_Threshold.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(stability[0]));w.writeheader();w.writerows(stability)
 meta={'schema':'phase7-illustrative-uncertainty-v1','case_count':len(CASE_SPECS),'scenario_count':len(scenes),'measurement_count':len(rows),
 'source_scenes':{t:sha(SRC/f'{t}.json') for t in scenes},
 'source_kind':'ARCHIVED_DERIVED_GEOMETRY_NOT_SUBMITTED_TABLE10',
 'compliance_assessment':'NOT_PERFORMED; SOME PERTURBED HARD FOOTPRINTS EXTEND PAST NET SHELL',
 'limits':['uncertain fixture identities','not empirical crowding calibration','no T5/T6/T7 in fixed-shell scenes','published Table 10 unreconciled','hard device centers fixed; no optimization or collision repairs'],
 'methods':'Exact edge partition in Phase5 engine, independent Shapely selected cases, fixed counts/centres and source ids.'}
 (OUT/'Phase7_Study_Metadata.json').write_text(json.dumps(meta,indent=2))
 print('CASES',len(CASE_SPECS),'MEASUREMENTS',len(rows),'independent cases',sum(x['grid_and_shapely_independently_checked']=='YES' for x in rows))
 for t in scenes:
  print(t,'BASE',next({k:round(r[k],4) for k in ['overlap_ratio_pct','cross_source_ratio_pct','pure_same_device_m2']} for r in rows if r['scenario']==t and r['case']=='BASE'))
 for t in ['L2','L3','L4']:
  print('\nRANGES',t, sorted([(x['factor'],round(x['all_ratio_range_pp'],2),round(x['cross_ratio_range_pp'],2)) for x in paired if x['scenario']==t],key=lambda v:-v[1]))
 print('cross L2->L3 always positive?', all(x['cross_L2_to_L3_positive'] for x in stability))
 print('cross any >50?', [x['case'] for x in stability if x['any_cross_over_50']])
 print('DONE',table)
if __name__=='__main__':main()
