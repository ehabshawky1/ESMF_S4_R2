#!/usr/bin/env python3
"""Reconstruct all fixed-shell research rectangles from DECLARED archived placement/dimension records.
NOT the original store-layout placement engine, and not the historical Table 10 calculation.
For T technology: hard rectangle from center and size; min/soft from hard plus offsets.
For fixture/service: rectangle from archived center and size (original parent rules unavailable).
Original stored rectangles and SVG provenance are independently checked; no values silently fitted.
"""
from pathlib import Path
import json,argparse,math
R=Path(__file__).resolve().parent.parent
SRC=R/'fixed_shell'/'declared_geometry_recipes';REF=R/'fixed_shell'/'scenes';DST=R/'fixed_shell'/'generated_scenes'

def make_rect(obj):
    x,y=obj['center_svg_units'];w,h=obj['size_svg_units']
    if not (w>0 and h>0 and all(map(math.isfinite,[x,y,w,h]))): raise ValueError('non-positive/non-finite dimensions')
    return [x-w/2,y-h/2,x+w/2,y+h/2]

def construct(r):
    scene={k:r[k] for k in ('scenario','source_kind','source_svg','source_sha256','units_per_metre','net_shell_svg_units','net_shell_m2','technology_device_counts','source_grouping_rule')}
    scene['schema']='ESMF-derived-pressure-scene-v1'
    scene['technology_hard_footprints']=[]
    hard={}
    for obj in r['hard_devices']:
        h={k:obj[k] for k in ('id','category','layer','source_group')};h['rect_svg_units']=make_rect(obj)
        if h['id'] in hard:raise ValueError('duplicated technology hard ID')
        hard[h['id']]=h
        scene['technology_hard_footprints'].append(h)
    scene['pressure_fields']=[]
    for obj in r['pressure_recipes']:
        f={k:obj[k] for k in ('id','category','layer','source_group')}
        construction=obj['construction']
        if construction['method']=='hard_footprint_with_explicit_edge_offsets':
            anchor=hard[construction['anchor_id']]['rect_svg_units']
            delta=construction['offsets_svg_units']
            if len(delta)!=4:raise ValueError('invalid offsets')
            rect=[anchor[i]+delta[i] for i in range(4)]
            f['construction']={'method':'hard_rect_plus_declared_edge_offsets','anchor_id':construction['anchor_id'],'offsets_svg_units':delta}
        elif construction['method']=='archived_placement_center_plus_extent':
            rect=make_rect(obj)
            f['construction']={'method':'explicit_archived_rectangle_no_parent_id'}
        else:raise ValueError('unknown declared geometry method')
        if not(rect[2]>rect[0] and rect[3]>rect[1]):raise ValueError('invalid generated rectangle')
        f['rect_svg_units']=rect
        scene['pressure_fields'].append(f)
    return scene

def verify_against_archived(generated,archived,tol=1e-6):
    for key in ('scenario','source_sha256','net_shell_svg_units','technology_device_counts'):
        if generated[key]!=archived[key]:raise ValueError('source mismatch: '+key)
    for key in ('technology_hard_footprints','pressure_fields'):
        a=generated[key];b=archived[key]
        if len(a)!=len(b):raise ValueError('count mismatch '+key)
        for m,n in zip(a,b):
            for k in ('id','category','source_group'):
                if m[k]!=n[k]:raise ValueError('identity mismatch '+k)
            if max(abs(u-v) for u,v in zip(m['rect_svg_units'],n['rect_svg_units']))>tol:raise ValueError('rectangle mismatch '+m['id'])
    return True

def main():
    DST.mkdir(parents=True,exist_ok=True)
    for tag in ('L1','L2','L3','L4'):
        r=json.loads((SRC/f'{tag}.json').read_text())
        output=construct(r)
        archived=json.loads((REF/f'{tag}.json').read_text())
        verify_against_archived(output,archived)
        (DST/f'{tag}.json').write_text(json.dumps(output,indent=2,ensure_ascii=False)+'\n')
        print(tag,'DECLARED_RECTANGLE_CONSTRUCTION_PASS',len(output['pressure_fields']),'pressure fields',len(output['technology_hard_footprints']),'devices')
    print('ALL_FOUR_DECLARED_GEOMETRY_RECONSTRUCTIONS_PASS True')
if __name__=='__main__':main()
