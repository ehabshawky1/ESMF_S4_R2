from __future__ import annotations
import sys, xml.etree.ElementTree as ET
from pathlib import Path

HARD_GROUPS = [
    'DISPLAY_WALL','DISPLAY_GONDOLA','DISPLAY_TABLE','DISPLAY_MANNEQUIN',
    'FITTING_ROOMS','CHECKOUT_COUNTER'
]

def rects_in_group(root, gid):
    out=[]
    for g in root.iter():
        if g.attrib.get('id')==gid:
            for e in g.iter():
                if e.tag.endswith('rect'):
                    try:
                        x=float(e.attrib.get('x','0')); y=float(e.attrib.get('y','0'))
                        w=float(e.attrib.get('width','0')); h=float(e.attrib.get('height','0'))
                    except ValueError:
                        continue
                    if w>0 and h>0:
                        out.append((x,y,w,h))
    return out

def positive_overlap(a,b,eps=1e-9):
    ax,ay,aw,ah=a; bx,by,bw,bh=b
    ix=min(ax+aw,bx+bw)-max(ax,bx)
    iy=min(ay+ah,by+bh)-max(ay,by)
    return ix>eps and iy>eps

def audit(svg_path: Path, requested: dict[str,int]):
    root=ET.parse(svg_path).getroot()
    trects={f'T{i}': rects_in_group(root,f'INTERACTIVE_T{i}') for i in range(1,10)}
    actual={k:len(v) for k,v in trects.items()}
    count_ok=all(actual.get(k,0)==requested.get(k,0) for k in requested) and all(actual.get(k,0)==0 for k in actual if k not in requested)

    # Independent hard-overlap audit among technology rectangles.
    all_t=[]
    for fam, rs in trects.items():
        for j,r in enumerate(rs,1): all_t.append((fam,j,r))
    tt=[]
    for i in range(len(all_t)):
        for j in range(i+1,len(all_t)):
            if positive_overlap(all_t[i][2], all_t[j][2]):
                tt.append((all_t[i][0],all_t[i][1],all_t[j][0],all_t[j][1]))

    # Independent audit of technology hard footprints against baseline hard fixtures/service objects.
    fixed=[]
    for gid in HARD_GROUPS:
        for j,r in enumerate(rects_in_group(root,gid),1): fixed.append((gid,j,r))
    tf=[]
    for fam,idx,r in all_t:
        for gid,j,fr in fixed:
            if positive_overlap(r,fr): tf.append((fam,idx,gid,j))

    return {
        'file':svg_path.name,
        'requested':requested,
        'actual':actual,
        'count_ok':count_ok,
        'technology_hard_overlap_count':len(tt),
        'technology_vs_baseline_hard_overlap_count':len(tf),
        'tt_examples':tt[:10],
        'tf_examples':tf[:10],
    }

def main():
    base=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent
    cases={
        'L2-Min(3).svg':{'T1':2,'T2':2,'T3':1,'T4':1,'T8':1,'T9':1},
        'L3-Min(3).svg':{'T1':4,'T2':4,'T3':1,'T4':1,'T8':1,'T9':1},
        'L4-Min(3).svg':{'T1':8,'T2':2,'T3':3,'T4':2,'T8':2,'T9':1},
    }
    ok=True
    for fn,req in cases.items():
        res=audit(base/fn,req)
        print(res)
        ok &= res['count_ok'] and res['technology_hard_overlap_count']==0 and res['technology_vs_baseline_hard_overlap_count']==0
    print('OVERALL_PASS=',ok)
    raise SystemExit(0 if ok else 1)
if __name__=='__main__': main()
