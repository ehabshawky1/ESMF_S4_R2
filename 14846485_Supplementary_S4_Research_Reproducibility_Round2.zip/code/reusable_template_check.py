#!/usr/bin/env python3
"""Check retrospective L2 technology buffer-template reuse in L3 and L4.
No claim of automatic planning or independent empirical validation.
"""
from pathlib import Path
import json,csv
R=Path(__file__).resolve().parent.parent
REC=R/'fixed_shell'/'declared_geometry_recipes'
def fields(tag):
    data=json.loads((REC/f'{tag}.json').read_text())
    hard={h['id']:h for h in data['hard_devices']}
    result=[]
    for f in data['pressure_recipes']:
        c=f['construction']
        if c['method'] != 'hard_footprint_with_explicit_edge_offsets': continue
        anchor=hard[c['anchor_id']]
        key=(f['layer'],round(anchor['size_svg_units'][0]),round(anchor['size_svg_units'][1]))
        offs=tuple(round(float(v),8) for v in c['offsets_svg_units'])
        result.append((f['id'],key,offs))
    return result
rules={k:o for _,k,o in fields('L2')}
assert len(rules)==12
for tag,expected in [('L3',(24,24)),('L4',(26,36))]:
    rows=fields(tag); pass_count=sum(rules.get(k)==o for _,k,o in rows)
    assert (pass_count,len(rows))==expected,(tag,pass_count,len(rows))
    print(tag,'L2_RULE_REUSE_EXACT',pass_count,'/',len(rows))
print('REUSABLE_ARCHIVED_FIELD_RULE_CHECK_PASS True')
