#!/usr/bin/env python3
from pathlib import Path
import subprocess,sys,csv,json,math
R=Path(__file__).resolve().parent

def call(args):
 p=subprocess.run([sys.executable,*args],cwd=R,capture_output=True,text=True)
 print('RUN',*args,'RETURN',p.returncode,'\n',p.stdout[-1400:]);print(p.stderr[-600:] if p.stderr else '')
 if p.returncode:raise RuntimeError('Reproduction command failed: '+str(args))
call(['code/construct_declared_geometry.py'])
call(['code/reusable_template_check.py'])
call(['fixed_shell/code/geometry_to_metrics.py'])
call(['sensitivity/code/phase7_sensitivity.py'])
call(['code/minimum_hard_geometry_audit.py','benchmarks_generated_minimum'])
rows=list(csv.DictReader((R/'fixed_shell/results/geometry_metrics.csv').open()))
assert len(rows)==4
expected={'L1':(74.20297205,26.938208,10.438208,0),'L2':(74.4406,46.8189,18.4552,8),'L3':(76.3345,52.3406,12.3213,12),'L4':(87.6566,66.8733,25.6740,18)}
for r in rows:
 ex=expected[r['scenario']]
 for i,key in enumerate(('unique_m2','raw_overlap_m2','cross_source_m2')):assert abs(float(r[key])-ex[i])<.00013,(r['scenario'],key,r[key],ex[i])
 assert int(r['device_count'])==ex[3]
sens=list(csv.DictReader((R/'sensitivity/results/Phase7_All_Sensitivity_Cases.csv').open()))
assert len(sens)==80,len(sens)
# match fixed shell to 4 sensitivity baseline cases
for r in rows:
 b=next(x for x in sens if x['scenario']==r['scenario'] and x['case']=='BASE')
 assert abs(float(b['unique_m2'])-float(r['unique_m2']))<1e-7
 assert abs(float(b['overlap_all_m2'])-float(r['raw_overlap_m2']))<1e-7
 assert abs(float(b['cross_source_m2'])-float(r['cross_source_m2']))<1e-7
(R/'results').mkdir(exist_ok=True)
import shutil
shutil.copy2(R/'fixed_shell/results/geometry_metrics.csv',R/'results/fixed_shell_metrics.csv')
(R/'results/run_report.json').write_text(json.dumps({'source':'DECLARED_ARCHIVED_DERIVED_GEOMETRY','fixed_shell_scenarios':4,'sensitivity_cases':80,'generated_minimum_hard_benchmarks':3,'historical_original_Table10_reconstructed':False,'status':'CALCULATION_VERIFIED_SOURCE_LIMITS_EXPLICIT'},indent=2)+'\n')
print('ROUND2_S4_CALCULATIONS_PASS True; historical_original_Table10_reconstructed False')
